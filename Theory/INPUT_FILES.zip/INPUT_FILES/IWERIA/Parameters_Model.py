import numpy as np
import matplotlib.pyplot as plt

kmax=20

# Note that in my definition of phi_10, the a10, a21,... is minus the definition by Misha, to be consistent with our definition of the field


def vpot(params,theta):
    
    F1,F2,wir,phi,a0,t1,energy_A,energy_B = params
    
    return np.array([-F1/wir*np.sin(theta) - 0.5*F2/wir*np.sin(2.0*theta+phi),
                     -F1/wir*np.cos(theta) + 0.5*F2/wir*np.cos(2.0*theta+phi)])

def eij(params,alpha,nn_hop):
    
    F1,F2,wir,phi,a0,t1,energy_A,energy_B = params
    rij = nn_hop*a0*np.array([np.sin(alpha),np.cos(alpha)])
    
    x_array = np.linspace(-np.pi,np.pi,1000000)
    dx= x_array[1]-x_array[0]
    integrand = np.exp(-1.0j*(np.dot(rij,vpot(params,x_array))) )

    return 1.0/(2.0*np.pi)*np.sum(integrand)*dx


F1 = (0.11e10 / 5.14220652e11)/np.sqrt(2.0)
F2 = (0.07e10 / 5.14220652e11)/np.sqrt(2.0)
wir = 0.387450603125/27.21
a0 = 3.4807420533333335
t1 = 0.089
energy_A = 0.5*1.67/27.21
energy_B = -0.5*1.67/27.21
energy_C = -0.5*1.67/27.21
energy_D = 0.5*1.67/27.21
phi = -DELAY_HERE*np.pi

params_low = [F1,F2,wir,phi,a0,t1,energy_A,energy_B]
params_up = [F1,F2,wir,phi,a0,t1,energy_C,energy_D]


e_B00_A00 = eij(params_low,np.radians(-90.0),1.0)
e_A00_B00 = eij(params_low,np.radians(90.0),1.0)
e_A00_B01 = eij(params_low,np.radians(-30.0),1.0)
e_B00_A0m1 = eij(params_low,np.radians(150.0),1.0)
e_A00_B10 = eij(params_low,np.radians(-150.0),1.0) 
e_B00_Am10 = eij(params_low,np.radians(30.0),1.0) 

e_A00_A01 = eij(params_low,np.radians(-60.0),np.sqrt(3.0))
e_B00_B01 = eij(params_low,np.radians(-60.0),np.sqrt(3.0))
e_A00_A0m1 = eij(params_low,np.radians(120.0),np.sqrt(3.0))
e_B00_B0m1 = eij(params_low,np.radians(120.0),np.sqrt(3.0))
e_A00_A10 = eij(params_low,np.radians(-120.0),np.sqrt(3.0))
e_B00_B10 = eij(params_low,np.radians(-120.0),np.sqrt(3.0))
e_A00_Am10 = eij(params_low,np.radians(60.0),np.sqrt(3.0))
e_B00_Bm10 = eij(params_low,np.radians(60.0),np.sqrt(3.0))
e_A00_A1m1 = eij(params_low,np.radians(180.0),np.sqrt(3.0))
e_B00_B1m1 = eij(params_low,np.radians(180.0),np.sqrt(3.0))
e_A00_Am11 = eij(params_low,np.radians(0.0),np.sqrt(3.0))
e_B00_Bm11 = eij(params_low,np.radians(0.0),np.sqrt(3.0))


e_D00_C00 = eij(params_up,np.radians(-90.0),1.0)
e_C00_D00 = eij(params_up,np.radians(90.0),1.0)
e_C00_D01 = eij(params_up,np.radians(-30.0),1.0)
e_D00_C0m1 = eij(params_up,np.radians(150.0),1.0)
e_C00_D10 = eij(params_up,np.radians(-150.0),1.0) 
e_D00_Cm10 = eij(params_up,np.radians(30.0),1.0) 

e_C00_C01 = eij(params_up,np.radians(-60.0),np.sqrt(3.0))
e_D00_D01 = eij(params_up,np.radians(-60.0),np.sqrt(3.0))
e_C00_C0m1 = eij(params_up,np.radians(120.0),np.sqrt(3.0))
e_D00_D0m1 = eij(params_up,np.radians(120.0),np.sqrt(3.0))
e_C00_C10 = eij(params_up,np.radians(-120.0),np.sqrt(3.0))
e_D00_D10 = eij(params_up,np.radians(-120.0),np.sqrt(3.0))
e_C00_Cm10 = eij(params_up,np.radians(60.0),np.sqrt(3.0))
e_D00_Dm10 = eij(params_up,np.radians(60.0),np.sqrt(3.0))
e_C00_C1m1 = eij(params_up,np.radians(180.0),np.sqrt(3.0))
e_D00_D1m1 = eij(params_up,np.radians(180.0),np.sqrt(3.0))
e_C00_Cm11 = eij(params_up,np.radians(0.0),np.sqrt(3.0))
e_D00_Dm11 = eij(params_up,np.radians(0.0),np.sqrt(3.0))




################## HOPPINGS ###########################

t_B00_A00 = t1*e_B00_A00
t_A00_B00 = t1*e_A00_B00
t_A00_B01 = t1*e_A00_B01
t_B00_A0m1 = t1*e_B00_A0m1
t_A00_B10 = t1*e_A00_B10
t_B00_Am10 = t1*e_B00_Am10

t2_A00_A01 = -t1**2/(energy_B-energy_A)* (e_A00_A01 -e_A00_B01*e_B00_A00)
t2_B00_B01 = -t1**2/(energy_A-energy_B)* (e_B00_B01 -e_B00_A00*e_A00_B01)
t2_A00_A0m1 = -t1**2/(energy_B-energy_A)* (e_A00_A0m1 -e_A00_B00*e_B00_A0m1)
t2_B00_B0m1 = -t1**2/(energy_A-energy_B)* (e_B00_B0m1 -e_B00_A0m1*e_A00_B00)
t2_A00_A10 = -t1**2/(energy_B-energy_A)* (e_A00_A10 -e_A00_B10*e_B00_A00)
t2_B00_B10 = -t1**2/(energy_A-energy_B)* (e_B00_B10 -e_B00_A00*e_A00_B10)
t2_A00_Am10 = -t1**2/(energy_B-energy_A)* (e_A00_Am10 -e_A00_B00*e_B00_Am10)
t2_B00_Bm10 = -t1**2/(energy_A-energy_B)* (e_B00_Bm10 -e_B00_Am10*e_A00_B00)
t2_A00_A1m1 = -t1**2/(energy_B-energy_A)* (e_A00_A1m1 -e_A00_B10*e_B00_A0m1)
t2_B00_B1m1 = -t1**2/(energy_A-energy_B)* (e_B00_B1m1 -e_B00_A0m1*e_A00_B10)
t2_A00_Am11 = -t1**2/(energy_B-energy_A)* (e_A00_Am11 -e_A00_B01*e_B00_Am10)
t2_B00_Bm11 = -t1**2/(energy_A-energy_B)* (e_B00_Bm11 -e_B00_Am10*e_A00_B01)




t_D00_C00 = t1*e_D00_C00
t_C00_D00 = t1*e_C00_D00
t_C00_D01 = t1*e_C00_D01
t_D00_C0m1 = t1*e_D00_C0m1
t_C00_D10 = t1*e_C00_D10
t_D00_Cm10 = t1*e_D00_Cm10

t2_C00_C01 = -t1**2/(energy_D-energy_C)* (e_C00_C01 -e_C00_D01*e_D00_C00)
t2_D00_D01 = -t1**2/(energy_C-energy_D)* (e_D00_D01 -e_D00_C00*e_C00_D01)
t2_C00_C0m1 = -t1**2/(energy_D-energy_C)* (e_C00_C0m1 -e_C00_D00*e_D00_C0m1)
t2_D00_D0m1 = -t1**2/(energy_C-energy_D)* (e_D00_D0m1 -e_D00_C0m1*e_C00_D00)
t2_C00_C10 = -t1**2/(energy_D-energy_C)* (e_C00_C10 -e_C00_D10*e_D00_C00)
t2_D00_D10 = -t1**2/(energy_C-energy_D)* (e_D00_D10 -e_D00_C00*e_C00_D10)
t2_C00_Cm10 = -t1**2/(energy_D-energy_C)* (e_C00_Cm10 -e_C00_D00*e_D00_Cm10)
t2_D00_Dm10 = -t1**2/(energy_C-energy_D)* (e_D00_Dm10 -e_D00_Cm10*e_C00_D00)
t2_C00_C1m1 = -t1**2/(energy_D-energy_C)* (e_C00_C1m1 -e_C00_D10*e_D00_C0m1)
t2_D00_D1m1 = -t1**2/(energy_C-energy_D)* (e_D00_D1m1 -e_D00_C0m1*e_C00_D10)
t2_C00_Cm11 = -t1**2/(energy_D-energy_C)* (e_C00_Cm11 -e_C00_D01*e_D00_Cm10)
t2_D00_Dm11 = -t1**2/(energy_C-energy_D)* (e_D00_Dm11 -e_D00_Cm10*e_C00_D01)





print("t_B00_A00_abs = ", np.abs(t_B00_A00) )
print("t_B00_A00_ang = ", np.angle(t_B00_A00) )
print("t_A00_B00_abs = ", np.abs(t_A00_B00) )
print("t_A00_B00_ang = ", np.angle(t_A00_B00) )
print("t2_A00_A01_abs = ", np.abs(t2_A00_A01) )
print("t2_A00_A01_ang = ", np.angle(t2_A00_A01) )
print("t_A00_B01_abs = ", np.abs(t_A00_B01) )
print("t_A00_B01_ang = ", np.angle(t_A00_B01) )
print("t2_B00_B01_abs = ", np.abs(t2_B00_B01) )
print("t2_B00_B01_ang = ", np.angle(t2_B00_B01) )
print("t2_A00_A0m1_abs = ", np.abs(t2_A00_A0m1) )
print("t2_A00_A0m1_ang = ", np.angle(t2_A00_A0m1) )
print("t_B00_A0m1_abs = ", np.abs(t_B00_A0m1) )
print("t_B00_A0m1_ang = ", np.angle(t_B00_A0m1) )
print("t2_B00_B0m1_abs = ", np.abs(t2_B00_B0m1) )
print("t2_B00_B0m1_ang = ", np.angle(t2_B00_B0m1) )
print("t2_A00_A10_abs = ", np.abs(t2_A00_A10) )
print("t2_A00_A10_ang = ", np.angle(t2_A00_A10) )
print("t_A00_B10_abs = ", np.abs(t_A00_B10) )
print("t_A00_B10_ang = ", np.angle(t_A00_B10) )
print("t2_B00_B10_abs = ", np.abs(t2_B00_B10) )
print("t2_B00_B10_ang = ", np.angle(t2_B00_B10) )
print("t2_A00_Am10_abs = ", np.abs(t2_A00_Am10) )
print("t2_A00_Am10_ang = ", np.angle(t2_A00_Am10) )
print("t_B00_Am10_abs = ", np.abs(t_B00_Am10) )
print("t_B00_Am10_ang = ", np.angle(t_B00_Am10) )
print("t2_B00_Bm10_abs = ", np.abs(t2_B00_Bm10) )
print("t2_B00_Bm10_ang = ", np.angle(t2_B00_Bm10) )
print("t2_A00_A1m1_abs = ", np.abs(t2_A00_A1m1) )
print("t2_A00_A1m1_ang = ", np.angle(t2_A00_A1m1) )
print("t2_B00_B1m1_abs = ", np.abs(t2_B00_B1m1) )
print("t2_B00_B1m1_ang = ", np.angle(t2_B00_B1m1) )
print("t2_A00_Am11_abs = ", np.abs(t2_A00_Am11) )
print("t2_A00_Am11_ang = ", np.angle(t2_A00_Am11) )
print("t2_B00_Bm11_abs = ", np.abs(t2_B00_Bm11) )
print("t2_B00_Bm11_ang = ", np.angle(t2_B00_Bm11) )
print("t_D00_C00_abs = ", np.abs(t_D00_C00) )
print("t_D00_C00_ang = ", np.angle(t_D00_C00) )
print("t_C00_D00_abs = ", np.abs(t_C00_D00) )
print("t_C00_D00_ang = ", np.angle(t_C00_D00) )
print("t2_C00_C01_abs = ", np.abs(t2_C00_C01) )
print("t2_C00_C01_ang = ", np.angle(t2_C00_C01) )
print("t_C00_D01_abs = ", np.abs(t_C00_D01) )
print("t_C00_D01_ang = ", np.angle(t_C00_D01) )
print("t2_D00_D01_abs = ", np.abs(t2_D00_D01) )
print("t2_D00_D01_ang = ", np.angle(t2_D00_D01) )
print("t2_C00_C0m1_abs = ", np.abs(t2_C00_C0m1) )
print("t2_C00_C0m1_ang = ", np.angle(t2_C00_C0m1) )
print("t_D00_C0m1_abs = ", np.abs(t_D00_C0m1) )
print("t_D00_C0m1_ang = ", np.angle(t_D00_C0m1) )
print("t2_D00_D0m1_abs = ", np.abs(t2_D00_D0m1) )
print("t2_D00_D0m1_ang = ", np.angle(t2_D00_D0m1) )
print("t2_C00_C10_abs = ", np.abs(t2_C00_C10) )
print("t2_C00_C10_ang = ", np.angle(t2_C00_C10) )
print("t_C00_D10_abs = ", np.abs(t_C00_D10) )
print("t_C00_D10_ang = ", np.angle(t_C00_D10) )
print("t2_D00_D10_abs = ", np.abs(t2_D00_D10) )
print("t2_D00_D10_ang = ", np.angle(t2_D00_D10) )
print("t2_C00_Cm10_abs = ", np.abs(t2_C00_Cm10) )
print("t2_C00_Cm10_ang = ", np.angle(t2_C00_Cm10) )
print("t_D00_Cm10_abs = ", np.abs(t_D00_Cm10) )
print("t_D00_Cm10_ang = ", np.angle(t_D00_Cm10) )
print("t2_D00_Dm10_abs = ", np.abs(t2_D00_Dm10) )
print("t2_D00_Dm10_ang = ", np.angle(t2_D00_Dm10) )
print("t2_C00_C1m1_abs = ", np.abs(t2_C00_C1m1) )
print("t2_C00_C1m1_ang = ", np.angle(t2_C00_C1m1) )
print("t2_D00_D1m1_abs = ", np.abs(t2_D00_D1m1) )
print("t2_D00_D1m1_ang = ", np.angle(t2_D00_D1m1) )
print("t2_C00_Cm11_abs = ", np.abs(t2_C00_Cm11) )
print("t2_C00_Cm11_ang = ", np.angle(t2_C00_Cm11) )
print("t2_D00_Dm11_abs = ", np.abs(t2_D00_Dm11) )
print("t2_D00_Dm11_ang = ", np.angle(t2_D00_Dm11) )


theta_arr = np.linspace(-np.pi,np.pi,1000)
plt.plot(vpot(params_low,theta_arr)[0],vpot(params_low,theta_arr)[1])
plt.xlabel("Ax")
plt.ylabel("Ay")
plt.savefig("vpot.png",dpi=300)

